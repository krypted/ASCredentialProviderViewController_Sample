//
//  ViewController.swift
//  MacOSCredential
//
//  Created by JSLIGH on 12/22/21.
//

import Cocoa

class ViewController: NSViewController, NSTextFieldDelegate {

    
    @IBOutlet weak var usernameSecureTF: NSSecureTextField!
    @IBOutlet weak var usernameTextField: NSTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        usernameTextField.isHidden = true
        usernameSecureTF.delegate = self
        usernameTextField.delegate = self
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    func controlTextDidChange(_ obj: Notification) {
        let object = obj.object as! NSTextField
        self.usernameTextField.stringValue = object.stringValue
        if self.usernameTextField.stringValue == ""
        {
            self.usernameTextField.isHidden = true
            self.usernameSecureTF.stringValue = ""
        }
        else
        {
            self.usernameTextField.isHidden = false
        }
    }
    
    


}

